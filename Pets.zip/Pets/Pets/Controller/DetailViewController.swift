//
//  DetailViewController.swift
//  Pets
//
//  Created by Yogender Saini on 18/12/22.
//

import UIKit
import WebKit

class DetailViewController: UIViewController, WKUIDelegate {

    var url = ""
    var webView: WKWebView!
    
    override func viewDidLoad() {
          super.viewDidLoad()
          let myURL = URL(string:url)
          let myRequest = URLRequest(url: myURL!)
          webView.load(myRequest)
       }
       override func loadView() {
          let webConfiguration = WKWebViewConfiguration()
          webView = WKWebView(frame: .zero, configuration: webConfiguration)
          webView.uiDelegate = self
          view = webView
       }
    
    static func getInstance() -> DetailViewController {
        let st = UIStoryboard(name: "Main", bundle: nil)
        return st.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
    }

}
