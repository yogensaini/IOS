//
//  ViewController.swift
//  Pets
//
//  Created by Yogender Saini on 17/12/22.
//

import UIKit

class ViewController: UIViewController, getPetDataDelegate, UITableViewDelegate, UITableViewDataSource {
    

    @IBOutlet weak var tblList : UITableView!
    let vm = PetsViewModel()
    var arrPets = [Pet]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        vm.delegate = self
        vm.getWorkingHrsTimeFromCofig()
        self.title = "Animals"
    }
    
    func getpetData(pets: [Pet], error: String) {
        self.arrPets = pets
        
        if self.arrPets.count >= 1 {
            let nib = UINib(nibName: "PetsTbCell", bundle: nil)
            self.tblList.register(nib, forCellReuseIdentifier: "PetsTbCell")
            self.tblList.dataSource = self
            self.tblList.delegate  = self
            self.tblList.reloadData()
            self.tblList.isHidden = false
        } else {
            self.tblList.isHidden = true
            vm.showAlert(errString: error, vc: self)
        }
    }

    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrPets.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PetsTbCell") as! PetsTbCell
        cell.setData(pet: self.arrPets[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {        
        let vc = DetailViewController.getInstance()
        vc.url = self.arrPets[indexPath.row].contentURL
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

