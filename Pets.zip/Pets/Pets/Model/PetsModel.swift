//
//  PetsModel.swift
//  Pets
//
//  Created by Yogender Saini on 17/12/22.
//

import UIKit


class PetsModel: Codable {
    let pets: [Pet]
}

struct Pet: Codable {
    let imageURL: String
    let title: String
    let contentURL: String
    let dateAdded: String
    
    enum CodingKeys: String, CodingKey {
            case imageURL = "image_url"
            case title
            case contentURL = "content_url"
            case dateAdded = "date_added"
        }
}

class SettingModel: Codable {
    let settings : [String:String]
}
