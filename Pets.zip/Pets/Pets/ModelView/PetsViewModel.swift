//
//  PetsViewModel.swift
//  Pets
//
//  Created by Yogender Saini on 17/12/22.
//

import UIKit
import Foundation

    
protocol getPetDataDelegate {
    func getpetData(pets: [Pet], error : String)
}

class PetsViewModel: NSObject {
    
    var delegate : getPetDataDelegate?
    var msgStr = ""
    
    func getWorkingHrsTimeFromCofig() {
        
        guard let url = Bundle.main.url(forResource: "config1", withExtension: "json") else {
            return
        }
        do {
            let data = try Data(contentsOf: url)
            do {
                let decoder = JSONDecoder()
                let result = try decoder.decode(SettingModel.self, from: data)
                let dict = result.settings
                let workHrs = dict["workHours"]!
                self.msgStr = workHrs
                self.checkTime(workingHrs: workHrs)
            } catch let err {
                debugPrint(err.localizedDescription)
            }
        } catch {
            print(error)
        }
    }
    
    
    func  checkTime(workingHrs : String) {
        var startHr = ""
        var endHR = ""
        var startMinuts = ""
        var endMinuts = ""
        
//        let workingHrs = "M-F 9:00 - 18:00" //"M-F 11:40 - 20:12"
        let pattern = "^[A-Z]-[A-Z]\\s{1}(\\d{1,2}:\\d{2})\\s{1}-\\s{1}(\\d{1,2}:\\d{2})$"
        let regex = try! NSRegularExpression(pattern: pattern)
        if let match = regex.matches(in: workingHrs, range: .init(workingHrs.startIndex..., in: workingHrs)).first,
           match.numberOfRanges == 3 {
            let start = match.range(at: 1)
            let startTime = workingHrs[Range(start, in: workingHrs)!]
            print(workingHrs[Range(start, in: workingHrs)!])
            startHr = String(startTime.prefix(2))
            startMinuts = String(startTime.suffix(2))

            let end = match.range(at: 2)
            let endTime = workingHrs[Range(end, in: workingHrs)!]
            print(workingHrs[Range(end, in: workingHrs)!])
            endHR = String(endTime.prefix(2))
            endMinuts = String(endTime.suffix(2))
            
            let check = self.CheckTimeExist(startHr: startHr, endHR: endHR, startMinuts: startMinuts, endMinuts: endMinuts)
            if check ==  true {
                self.getDataFromList()
            } else {
                self.delegate?.getpetData(pets: [], error: "Please log in working hours, \(self.msgStr)")
            }
        }
    }

    
    func CheckTimeExist(startHr : String, endHR  : String, startMinuts  : String, endMinuts  : String)->Bool{
        
        var timeExist:Bool
        let calendar = Calendar.current
        let startTimeComponent = DateComponents(calendar: calendar, hour: Int(startHr), minute: Int(startMinuts))
        let endTimeComponent   = DateComponents(calendar: calendar, hour: Int(endHR), minute: Int(endMinuts))
        
        let now = Date()
        let startOfToday = calendar.startOfDay(for: now)
        let startTime    = calendar.date(byAdding: startTimeComponent, to:
                                            startOfToday)!
        let endTime      = calendar.date(byAdding: endTimeComponent, to:
                                            startOfToday)!
        
        if startTime <= now && now <= endTime {
            print("Logged in working hrs")
            timeExist = true
        } else {
            print("not logged in working hrs")
            timeExist = false
        }
        return timeExist
    }
    
    func getDataFromList() {
        
        guard let url = Bundle.main.url(forResource: "pets_list", withExtension: "json") else {
            return
        }
        do {
            let data = try Data(contentsOf: url)
            do {
                let decoder = JSONDecoder()
                let result = try decoder.decode(PetsModel.self, from: data)
                self.delegate?.getpetData(pets: result.pets, error: "Wrong working hours")
            } catch let err {
                debugPrint(err.localizedDescription)
                self.delegate?.getpetData(pets: [], error: err.localizedDescription)
            }
        } catch {
            print(error)
        }
    }
    
    func showAlert(errString : String, vc : UIViewController) {
        let alert = UIAlertController(title: "Oops", message: errString, preferredStyle: UIAlertController.Style.alert)

        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
        }))

        vc.present(alert, animated: true, completion: nil)
        
    }
}
